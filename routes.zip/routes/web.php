<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\IncomingDocumentController;
use App\Http\Controllers\OutgoingDocumentController;

use App\Http\Controllers\CommonDocumentController;


Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

Route::get('/incoming', [IncomingDocumentController::class, 'index'])->name('incoming.index');
Route::get('/outgoing', [OutgoingDocumentController::class, 'index'])->name('outgoing.index');

Route::get('/documents/create', function () {
    return view('documents.create');
})->name('documents.create');

Route::post('/incoming/store', [IncomingDocumentController::class, 'store'])
    ->name('incoming.store');

Route::post('/outgoing/store', [OutgoingDocumentController::class, 'store'])
    ->name('outgoing.store');

Route::get('/documents/common', function () {
    $incoming = \App\Models\IncomingDocument::select(
        'protocol_number',
        'incoming_protocol',
        'incoming_date',
        'subject',
        'sender',
        'document_date',
        'summary',
        'comments',
        \DB::raw("'Εισερχόμενο' as type")
    );

    $outgoing = \App\Models\OutgoingDocument::select(
        'protocol_number',
        'incoming_protocol',
        'incoming_date',
        'subject',
        'sender',
        'document_date',
        'summary',
        'comments',
        \DB::raw("'Εξερχόμενο' as type")
    );

    $documents = $incoming->unionAll($outgoing)
        ->orderBy('incoming_date', 'desc')
        ->paginate(10);

    return view('documents.common', compact('documents'));
})->name('documents.common');

// Incoming
Route::get('/incoming/{id}/edit', [IncomingDocumentController::class, 'edit'])->name('incoming.edit');
Route::put('/incoming/{id}', [IncomingDocumentController::class, 'update'])->name('incoming.update');
Route::delete('/incoming/{id}', [IncomingDocumentController::class, 'destroy'])->name('incoming.destroy');

// Outgoing
Route::get('/outgoing/{id}/edit', [OutgoingDocumentController::class, 'edit'])->name('outgoing.edit');
Route::put('/outgoing/{id}', [OutgoingDocumentController::class, 'update'])->name('outgoing.update');
Route::delete('/outgoing/{id}', [OutgoingDocumentController::class, 'destroy'])->name('outgoing.destroy');




Route::get('/documents/common', [CommonDocumentController::class, 'index'])
    ->name('documents.common');




Route::get('/', function () {
    return view('dashboard');
})->name('dashboard');

Route::get('/incoming', [IncomingDocumentController::class, 'index'])->name('incoming.index');
Route::post('/incoming/store', [IncomingDocumentController::class, 'store'])->name('incoming.store');

Route::get('/outgoing', [OutgoingDocumentController::class, 'index'])->name('outgoing.index');
Route::post('/outgoing/store', [OutgoingDocumentController::class, 'store'])->name('outgoing.store');

Route::get('/documents/common', [CommonDocumentController::class, 'index'])
    ->name('documents.common');




