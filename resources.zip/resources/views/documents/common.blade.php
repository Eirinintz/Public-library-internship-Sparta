@extends('layouts.app')

@section('content')

<div class="card p-4 mb-5">
    <h2>Κοινή Προβολή Εισερχομένων</h2>

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Α/Α</th>
            <th>Ημερομηνία Παραλαβής</th>
            <th>Αριθμός Εισερχομένου</th>
            <th>Τόπος</th>
            <th>Αρχή</th>
            <th>Χρονολογία</th>
            <th>Περίληψη</th>
            <th>Φάκελος</th>
        </tr>
        </thead>
        <tbody>
        @forelse($common_incoming as $doc)
            <tr>
                <td>{{ $doc->aa ?? '' }}</td>
                <td>{{ $doc->received_date ?? '' }}</td>
                <td>{{ $doc->incoming_number ?? '' }}</td>
                <td>{{ $doc->place ?? '' }}</td>
                <td>{{ $doc->authority ?? '' }}</td>
                <td>{{ $doc->year ?? '' }}</td>
                <td>{{ $doc->summary ?? '' }}</td>
                <td>{{ $doc->folder ?? '' }}</td>
            </tr>
        @empty
            <tr><td colspan="8">Δεν υπάρχουν εγγραφές</td></tr>
        @endforelse
        </tbody>
    </table>
</div>

<div class="card p-4">
    <h2>Κοινή Προβολή Εξερχομένων</h2>

    <table border="1" width="100%" cellpadding="5">
        <thead>
        <tr>
            <th>Α/Α</th>
            <th>Αρχή</th>
            <th>Περίληψη</th>
            <th>Χρονολογία</th>
            <th>Σχετικοί Αριθμοί</th>
            <th>Φάκελος</th>
            <th>Παρατηρήσεις</th>
        </tr>
        </thead>
        <tbody>
        @forelse($common_outgoing as $doc)
            <tr>
                <td>{{ $doc->aa ?? '' }}</td>
                <td>{{ $doc->target ?? '' }}</td>
                <td>{{ $doc->summary ?? '' }}</td>
                <td>{{ $doc->year ?? '' }}</td>
                <td>{{ $doc->related ?? '' }}</td>
                <td>{{ $doc->folder ?? '' }}</td>
                <td>{{ $doc->notes ?? '' }}</td>
            </tr>
        @empty
            <tr><td colspan="7">Δεν υπάρχουν εγγραφές</td></tr>
        @endforelse
        </tbody>
    </table>
</div>

@endsection
