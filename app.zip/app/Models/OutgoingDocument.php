<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class OutgoingDocument extends Model
{
    protected $table = 'outgoing_documents';

    protected $fillable = [
        'aa',
        'target',
        'summary',
        'year',
        'related',
        'folder',
        'notes',
        'outgoing_date',
    ];
}
