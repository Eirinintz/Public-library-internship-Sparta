<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IncomingDocument extends Model
{
    protected $table = 'incoming_documents';

    protected $fillable = [
        'aa',
        'received_date',
        'incoming_number',
        'place',
        'authority',
        'year',
        'summary',
        'folder',
    ];
}


