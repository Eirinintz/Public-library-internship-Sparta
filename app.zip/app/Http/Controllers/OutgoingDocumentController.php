<?php

namespace App\Http\Controllers;

use App\Models\OutgoingDocument;
use Illuminate\Http\Request;

class OutgoingDocumentController extends Controller
{
    public function index()
    {
    $documents = OutgoingDocument::orderBy('document_date', 'desc')->paginate(10);
    return view('outgoing.index', compact('documents'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'protocol_number' => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date' => 'nullable|date',
            'subject' => 'nullable|string',
            'sender' => 'nullable|string',
            'document_date' => 'nullable|date',
            'incoming_document_number' => 'nullable|string',
            'summary' => 'nullable|string',
            'comments' => 'nullable|string',
        ]);

        OutgoingDocument::create($validated);

        return redirect()->back()->with('success', 'Το εξερχόμενο καταχωρήθηκε επιτυχώς.');
    }
    public function edit($id)
    {
           $document = OutgoingDocument::findOrFail($id);
           return view('outgoing.edit', compact('document'));
    }

    public function update(Request $request, $id)
    {
         $validated = $request->validate([
            'protocol_number' => 'nullable|string',
            'incoming_protocol' => 'nullable|string',
            'incoming_date' => 'nullable|date',
            'subject' => 'nullable|string',
            'sender' => 'nullable|string',
            'document_date' => 'nullable|date',
            'incoming_document_number' => 'nullable|string',
            'summary' => 'nullable|string',
            'comments' => 'nullable|string',
            ]);
 
     OutgoingDocument::findOrFail($id)->update($validated);

     return redirect()->route('outgoing.index')->with('success', 'Το εξερχόμενο ενημερώθηκε.');
    }

     public function destroy($id)
     {
          OutgoingDocument::findOrFail($id)->delete();
          return redirect()->back()->with('success', 'Το εξερχόμενο διαγράφηκε.');
     }
}

