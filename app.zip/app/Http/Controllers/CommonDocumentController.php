<?php

namespace App\Http\Controllers;

use App\Models\IncomingDocument;
use App\Models\OutgoingDocument;
use Carbon\Carbon;

class CommonDocumentController extends Controller
{
    public function index()
    {
        // Παίρνουμε όλα τα εισερχόμενα και εξερχόμενα
        $incoming = IncomingDocument::all();
        $outgoing = OutgoingDocument::all();

        // Normalized ημερομηνίες για σύγκριση
        $incomingDates = $incoming->map(fn($doc) => $this->normalizeDate($doc->incoming_number))
                                  ->filter()
                                  ->toArray();

        $outgoingDates = $outgoing->map(fn($doc) => $this->normalizeDate($doc->year))
                                  ->filter()
                                  ->toArray();

        // Κοινές ημερομηνίες
        $commonDates = array_intersect($incomingDates, $outgoingDates);

        // Φιλτράρουμε τα κοινά εισερχόμενα
        $common_incoming = $incoming->filter(fn($doc) => in_array($this->normalizeDate($doc->incoming_number), $commonDates));

        // Φιλτράρουμε τα κοινά εξερχόμενα
        $common_outgoing = $outgoing->filter(fn($doc) => in_array($this->normalizeDate($doc->year), $commonDates));

        // Προσθέτουμε default κενά αν κάποιο πεδίο είναι null για την εμφάνιση
        $common_incoming->transform(function ($doc) {
            $doc->aa = $doc->aa ?? '';
            $doc->received_date = $doc->received_date ?? '';
            $doc->incoming_number = $doc->incoming_number ?? '';
            $doc->place = $doc->place ?? '';
            $doc->authority = $doc->authority ?? '';
            $doc->year = $doc->year ?? '';
            $doc->summary = $doc->summary ?? '';
            $doc->folder = $doc->folder ?? '';
            return $doc;
        });

        $common_outgoing->transform(function ($doc) {
            $doc->aa = $doc->aa ?? '';
            $doc->target = $doc->target ?? '';
            $doc->summary = $doc->summary ?? '';
            $doc->year = $doc->year ?? '';
            $doc->related = $doc->related ?? '';
            $doc->folder = $doc->folder ?? '';
            $doc->notes = $doc->notes ?? '';
            return $doc;
        });

        return view('documents.common', compact('common_incoming', 'common_outgoing'));
    }

    /**
     * Normalize ημερομηνία ώστε να είναι σε μορφή Y-m-d για σύγκριση
     */
    private function normalizeDate($value)
    {
        try {
            return Carbon::parse($value)->format('Y-m-d');
        } catch (\Exception $e) {
            return null;
        }
    }
}
